import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Random;

public class GamePanel extends JPanel implements ActionListener {
    static final int SCREEN_WIDTH = 600;
    static final int SCREEN_HEIGHT = 600;
    static final int UNIT_SIZE = 25;
    static final int GAME_UNITS = (SCREEN_WIDTH*SCREEN_HEIGHT)/2;
    int DELAY = 75;
    Timer timer;
    Random random;
    int barLength = 5;
    int ballsCaught;
    int ballsMissed;
    int level = 1;
    char barDirection;
    char ballDirection = 'D';
    boolean running = false;
    int score;
    int ballX[] = new int[GAME_UNITS];
    int ballY[] = new int[GAME_UNITS];
    int barX[] = new int[GAME_UNITS];
    int barY[] = new int[GAME_UNITS];

    //set colors
    int myRed = 255;
    int myGreen = 255;
    int myBlue = 255;

    GamePanel() {
        random = new Random();
        this.setFocusable(true);
        this.setPreferredSize(new Dimension(SCREEN_WIDTH, SCREEN_HEIGHT));
        this.setBackground(Color.black);
        this.addKeyListener(new MyKeyAdapter());
        startGame();
    }

    public void startGame() {
        running = true;
        newBall();
        timer = new Timer(DELAY, this);
        timer.start();
    }
    public void newBall() {
        ballX[0] = (int) random.nextInt(SCREEN_WIDTH/UNIT_SIZE)*UNIT_SIZE;
        ballY[0] = 0;
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        draw(g);
    }

    public void draw(Graphics g) {
        if (running) {
            //draw bar
            g.setColor(new Color(myRed, myGreen, myBlue));
            g.fillRect(barX[0], 550, (UNIT_SIZE*barLength), UNIT_SIZE);

            //draw ball
            g.setColor(new Color(myRed, myGreen, myBlue));
            g.fillOval(ballX[0], ballY[0], UNIT_SIZE, UNIT_SIZE);

            //print balls caught
            g.setColor(new Color(myRed, myGreen, myBlue));
            g.setFont(new Font("Ink Free", Font.BOLD, 20));
            FontMetrics metrics1 = getFontMetrics(g.getFont());
            g.drawString("Balls Caught: " + ballsCaught, (260), g.getFont().getSize());

            //print balls missed
            g.setColor(Color.red);
            g.setFont(new Font("Ink Free", Font.BOLD, 20));
            FontMetrics metrics2 = getFontMetrics(g.getFont());
            g.drawString("Balls Missed: " + ballsMissed, (50), g.getFont().getSize());

            //print level
            g.setColor(Color.red);
            g.setFont(new Font("Ink Free", Font.BOLD, 20));
            FontMetrics metrics3 = getFontMetrics(g.getFont());
            g.drawString("Level: " + level, (460), g.getFont().getSize());
        }
        else if (!running && ballsCaught >= 25) {
            youWin(g);
        }
        else {
            gameOver(g);
        }
    }

    public void moveBar() {
        for(int i = 1; i > 0; i--) {
            barX[i] = barX[i-1];
        }
        switch (barDirection) {
            case 'L':
                barX[0] = barX[0] - UNIT_SIZE;
                break;
            case 'R':
                barX[0] = barX[0] + UNIT_SIZE;
                break;
            case 'N':
                barX[0] = barX[0];
                break;
        }
    }

    public void moveBall() {
        for(int i = 1; i > 0; i--) {
            ballX[i] = ballX[i-1];
            ballY[i] = ballY[i-1];
        }
        switch (ballDirection) {
            case 'L':
                ballX[0] = ballX[0] - UNIT_SIZE;
                break;
            case 'R':
                ballX[0] = ballX[0] + UNIT_SIZE;
                break;
            case 'U':
                ballY[0] = ballY[0] - UNIT_SIZE;
                break;
            case 'D':
                ballY[0] = ballY[0] + UNIT_SIZE;
                break;
        }
    }

    public void ballCollisions() {
        if (((ballX[0] >= barX[0]) && (ballX[0] <= barX[0]+UNIT_SIZE*barLength)) && (ballY[0] == 550)) {
            ballsCaught++;
            newBall();
        }

        //ball touches top border
        if (ballY[0] < 0) {
            newBall();
        }

        //ball touches bottom border
        if (ballY[0] > SCREEN_HEIGHT) {
            ballsMissed++;
            newBall();
        }

        if(!running) {
            timer.stop();
        }
    }

    public void barCollisions() {
        //check if bar touches left border
        if(barX[0] == 0) {
            barDirection = 'N';
        }
        //check if bar touches right border
        if(barX[0]+UNIT_SIZE*barLength == SCREEN_WIDTH) {
            barDirection = 'N';
        }
    }

    public void checkProgress() {
        if (ballsCaught >= 5) {
            level = 2;
            DELAY = 50;
            barLength = 4;

            //set colors
            myRed = 0;
            myGreen = 255;
            myBlue = 0;
        }
        if (ballsCaught >= 10) {
            level = 3;
            DELAY = 25;
            barLength = 3;

            //set colors
            myRed = 0;
            myGreen = 153;
            myBlue = 255;
        }
        if (ballsCaught >= 15) {
            level = 4;
            DELAY = 15;
            barLength = 2;

            //set colors
            myRed = 255;
            myGreen = 255;
            myBlue = 0;
        }
        if (ballsCaught >= 20) {
            level = 4;
            DELAY = 10;
            barLength = 1;

            //set colors
            myRed = 204;
            myGreen = 0;
            myBlue = 255;
        }
        if (ballsCaught >= 25) {
            running = false;
        }
        if (ballsMissed >= 10) {
            running = false;
        }
    }

    public int calculateScore() {
        score = (ballsCaught*4-(ballsMissed*2));
        return score;
    }

    public void gameOver(Graphics g) {
        //Display Score
        g.setColor(Color.red);
        g.setFont(new Font("Ink Free", Font.BOLD, 40));
        FontMetrics metrics1 = getFontMetrics(g.getFont());
        g.drawString("Score: " + calculateScore(), (SCREEN_WIDTH - metrics1.stringWidth("Score: " + calculateScore()))/2, g.getFont().getSize());

        //Game Over Text
        g.setColor(Color.red);
        g.setFont(new Font("Ink Free", Font.BOLD, 50));
        FontMetrics metrics2 = getFontMetrics(g.getFont());
        g.drawString("Game Over", (SCREEN_WIDTH - metrics2.stringWidth("Game Over"))/2, SCREEN_HEIGHT/2);
    }

    public void youWin(Graphics g) {
        //Display Score
        g.setColor(new Color(random.nextInt(255),random.nextInt(255),random.nextInt(255)));
        g.setFont(new Font("Ink Free", Font.BOLD, 40));
        FontMetrics metrics1 = getFontMetrics(g.getFont());
        g.drawString("Score: " + calculateScore(), (SCREEN_WIDTH - metrics1.stringWidth("Score: " + calculateScore()))/2, g.getFont().getSize());

        //You Win Text
        g.setColor(new Color(random.nextInt(255),random.nextInt(255),random.nextInt(255)));
        g.setFont(new Font("Ink Free", Font.BOLD, 50));
        FontMetrics metrics2 = getFontMetrics(g.getFont());
        g.drawString("Winner", (SCREEN_WIDTH - metrics2.stringWidth("Winner"))/2, SCREEN_HEIGHT/2);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (running) {
            moveBar();
            moveBall();
            ballCollisions();
            checkProgress();
            barCollisions();
        }
        repaint();
    }

    public class MyKeyAdapter extends KeyAdapter {
        public void keyPressed(KeyEvent e) {
            switch (e.getKeyCode()) {
                case KeyEvent.VK_LEFT:
                    barDirection = 'L';
                    break;
                case KeyEvent.VK_RIGHT:
                    barDirection = 'R';
                    break;
            }
        }
    }
}
